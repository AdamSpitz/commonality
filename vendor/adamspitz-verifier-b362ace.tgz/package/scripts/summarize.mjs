#!/usr/bin/env node

/**
 * Read all verifier check definitions under checks/ and produce a Markdown
 * document describing the DAG — every check and how they connect.
 *
 * Usage:
 *   node summarize.mjs [output file]   (default: stdout)
 */

import fs from "node:fs";
import path from "node:path";

function findDefFiles(checksDir) {
  const out = [];
  const entries = fs.readdirSync(checksDir, { withFileTypes: true });
  for (const entry of entries) {
    const full = path.join(checksDir, entry.name);
    if (entry.isDirectory()) {
      out.push(...findDefFiles(full));
    } else if (entry.isFile() && entry.name.endsWith(".def.json")) {
      out.push(full);
    }
  }
  return out;
}

function loadDefs(workspaceDir) {
  const checksDir = path.join(workspaceDir, "checks");
  const defFiles = findDefFiles(checksDir);
  const defs = [];
  for (const file of defFiles) {
    const raw = fs.readFileSync(file, "utf-8");
    const def = JSON.parse(raw);
    // strip lib/ helpers (no id field)
    if (!def.id) continue;
    def._sourcePath = path.relative(workspaceDir, file);
    defs.push(def);
  }
  return defs;
}

/**
 * Build a map from check id to its def, and a reverse map from id to the set
 * of parent check ids that reference it as a child input.
 */
function buildGraph(defs) {
  const byId = new Map();
  const parentsOf = new Map(); // childId -> Set<parentId>

  for (const def of defs) {
    byId.set(def.id, def);
  }

  for (const def of defs) {
    const childInputs = (def.inputs ?? []).filter((inp) => inp.kind === "check");
    for (const child of childInputs) {
      if (!parentsOf.has(child.id)) parentsOf.set(child.id, new Set());
      parentsOf.get(child.id).add(def.id);
    }
  }

  return { byId, parentsOf };
}

function slugifyCheckId(id) {
  return id.replace(/\./g, "-");
}

function triggerLabel(t) {
  if (!t) return "?";
  if (t.type === "manual") return "Manual";
  if (t.type === "cron") return `Every ${t.everyMinutes}m`;
  return t.type;
}

function retentionLabel(r) {
  if (!r) return "";
  const parts = [];
  if (r.keep !== undefined) parts.push(`${r.keep} runs`);
  if (r.keepDays !== undefined) parts.push(`${r.keepDays}d`);
  return parts.join(", ");
}

function hasSupervisorScript(def) {
  const cmd = def.command ?? [];
  return cmd.some((seg) => seg.includes("supervisor.mjs"));
}

function isReviewAttestation(def) {
  const cmd = def.command ?? [];
  return cmd.some((seg) => seg.includes("report-attestation.mjs"));
}

function isLlmJudgment(def) {
  const cmd = def.command ?? [];
  return cmd.some((seg) => seg.includes("llm-judgment.mjs"))
    || def.id === "meta.llm-check-review"
    || def.id === "meta.llm-to-automated-candidates";
}

function isKnownBad(def) {
  const cmd = def.command ?? [];
  return cmd.some((seg) => seg.includes("known-bad") || seg.includes("expect-bad-result"));
}

function checkKind(def) {
  // Any check that has child check inputs is a supervisor, whether it uses
  // supervisor.mjs or a custom script (e.g. validation/pr.mjs).
  const hasChildren = childInputs(def).length > 0;
  if (hasChildren) return "Supervisor (rollup)";
  if (isReviewAttestation(def)) return "Report attestation";
  if (isLlmJudgment(def)) return "LLM judgment";
  if (isKnownBad(def)) return "Known-bad fixture";
  if ((def.command ?? []).some((seg) => seg.includes("run-command-check"))) return "Shell command";
  return "Leaf check";
}

function childInputs(def) {
  return (def.inputs ?? []).filter((inp) => inp.kind === "check");
}

function renderTableOfContents(defs, parentsOf, byId) {
  const lines = ["## Table of Contents", ""];

  // Group by top-level namespace prefix
  const groups = new Map();
  for (const def of defs) {
    const ns = def.id.split(".")[0];
    if (!groups.has(ns)) groups.set(ns, []);
    groups.get(ns).push(def);
  }

  // Order groups sensibly
  const groupOrder = [
    "root",
    "validation",
    "automated",
    "ai-fixtures",
    "artifact",
    "stack",
    "operations",
    "env",
    "coverage",
    "staleness",
    "known-bad",
    "review",
    "meta",
  ];

  for (const ns of groupOrder) {
    const groupDefs = groups.get(ns);
    if (!groupDefs || groupDefs.length === 0) continue;
    groups.delete(ns);

    const label =
      ns === "ai-fixtures" ? "AI Fixtures" :
      ns === "known-bad" ? "Known-Bad Fixtures" :
      ns === "review" ? "Review & Attestation" :
      ns === "meta" ? "Meta / Verifier Health" :
      ns.charAt(0).toUpperCase() + ns.slice(1);

    lines.push(`- **${label}**`);
    for (const def of groupDefs.sort((a, b) => a.id.localeCompare(b.id))) {
      const hasChildren = childInputs(def).length > 0;
      const isLeaf = !hasChildren;
      const icon = hasChildren ? "📦" : "🔹";
      const anchor = slugifyCheckId(def.id);
      lines.push(`  - ${icon} [\`${def.id}\`](#${anchor})${isLeaf ? "" : " *(supervisor)*"}`);
    }
  }

  // Any remaining groups
  for (const [ns, groupDefs] of [...groups.entries()].sort((a, b) => a[0].localeCompare(b[0]))) {
    lines.push(`- **${ns.charAt(0).toUpperCase() + ns.slice(1)}**`);
    for (const def of groupDefs.sort((a, b) => a.id.localeCompare(b.id))) {
      const hasChildren = childInputs(def).length > 0;
      const icon = hasChildren ? "📦" : "🔹";
      const anchor = slugifyCheckId(def.id);
      lines.push(`  - ${icon} [\`${def.id}\`](#${anchor})${hasChildren ? "" : " *(supervisor)*"}`);
    }
  }

  lines.push("");
  return lines;
}

function renderCheckDetail(def, parentsOf, byId) {
  const lines = [];
  const anchor = slugifyCheckId(def.id);
  lines.push(`### \`${def.id}\` {#${anchor}}`, "");

  lines.push(`- **Description:** ${def.description}`);
  lines.push(`- **Trigger:** ${triggerLabel(def.trigger)}`);
  if (retentionLabel(def.retention)) {
    lines.push(`- **Retention:** ${retentionLabel(def.retention)}`);
  }
  if (def.timeoutMs) {
    lines.push(`- **Timeout:** ${def.timeoutMs}ms`);
  }
  lines.push(`- **Kind:** ${checkKind(def)}`);
  lines.push(`- **Source:** \`${def._sourcePath}\``);
  if (def.command) {
    lines.push(`- **Command:** \`${def.command.join(" ")}\``);
  }
  lines.push("");

  // Child checks (inputs of kind "check")
  const children = childInputs(def);

  if (children.length > 0) {
    lines.push("**Child checks:**");
    lines.push("");
    for (const child of children) {
      const childDef = byId.get(child.id);
      const role = child.role || "";
      lines.push(`- [\`${child.id}\`](#${slugifyCheckId(child.id)})${role ? ` — ${role}` : ""}`);
      if (childDef) {
        lines.push(`  > ${childDef.description}`);
      }
    }
    lines.push("");
  }

  // Advisory children (from params)
  const params = (def.inputs ?? [])
    .filter((inp) => inp.kind === "params")
    .map((inp) => inp.data ?? {});
  const merged = Object.assign({}, ...params);
  if (merged.advisoryCheckIds && merged.advisoryCheckIds.length > 0) {
    lines.push("**Advisory children (non-gating):**");
    lines.push("");
    for (const advId of merged.advisoryCheckIds) {
      lines.push(`- [\`${advId}\`](#${slugifyCheckId(advId)})`);
    }
    lines.push("");
  }

  // Rollup rule
  if (merged.rollup) {
    lines.push(`**Rollup rule:** \`${JSON.stringify(merged.rollup)}\``);
    lines.push("");
  }

  // Freshness policy
  if (merged.freshness) {
    lines.push(`**Freshness policy:** \`${JSON.stringify(merged.freshness)}\``);
    lines.push("");
  }

  // Parents (checks that reference this one)
  const parents = parentsOf.get(def.id);
  if (parents && parents.size > 0) {
    lines.push("**Used by:**");
    lines.push("");
    for (const pid of [...parents].sort()) {
      lines.push(`- [\`${pid}\`](#${slugifyCheckId(pid)})`);
    }
    lines.push("");
  }

  lines.push("---");
  lines.push("");
  return lines;
}

function renderDagAscii(defs, parentsOf, byId) {
  const lines = ["## Dependency Graph", "", "```", ""];

  const indentedIds = new Set();
  for (const def of defs) {
    const children = childInputs(def);
    for (const child of children) {
      indentedIds.add(child.id);
    }
  }

  // Print root-level checks first (not children of any other check)
  const rootChecks = defs.filter((d) => !indentedIds.has(d.id));
  const rootIds = new Set(rootChecks.map((d) => d.id));

  function printTree(id, prefix) {
    const def = byId.get(id);
    if (!def) {
      lines.push(`${prefix}${id} (missing def)`);
      return;
    }
    const kind = checkKind(def);
    lines.push(`${prefix}${id}${kind ? `  ▶ ${kind}` : ""}`);

    const children = childInputs(def);
    // Also include advisory children (displayed differently)
    const params = (def.inputs ?? [])
      .filter((inp) => inp.kind === "params")
      .map((inp) => inp.data ?? {});
    const merged = Object.assign({}, ...params);
    const advisoryIds = merged.advisoryCheckIds ?? [];

    const directChildren = children.filter((c) => !advisoryIds.includes(c.id));
    const advisoryOnly = children.filter((c) => advisoryIds.includes(c.id));

    for (let i = 0; i < directChildren.length; i++) {
      const isLast = i === directChildren.length - 1 && advisoryOnly.length === 0;
      const connector = isLast ? "└── " : "├── ";
      const childPrefix = isLast ? "    " : "│   ";
      printTree(directChildren[i].id, prefix + connector, rootIds, byId, childPrefix);
    }

    for (let i = 0; i < advisoryOnly.length; i++) {
      const isLast = i === advisoryOnly.length - 1;
      const connector = isLast ? "└── " : "├── ";
      const childPrefix = isLast ? "    " : "│   ";
      lines.push(`${prefix}${connector}${advisoryOnly[i].id} (advisory)`);
    }
  }

  // We need a recursive version with proper prefix handling
  function printTreeRec(id, prefix, rootIds, byId, indent) {
    const def = byId.get(id);
    if (!def) {
      lines.push(`${indent}${prefix}${id} (missing def)`);
      return;
    }

    const kind = checkKind(def);
    let label = `${id}`;
    if (!rootIds.has(id)) {
      label += `  ▶ ${kind}`;
    }
    lines.push(`${indent}${prefix}${label}`);

    const children = childInputs(def);
    const params = (def.inputs ?? [])
      .filter((inp) => inp.kind === "params")
      .map((inp) => inp.data ?? {});
    const merged = Object.assign({}, ...params);
    const advisoryIds = new Set(merged.advisoryCheckIds ?? []);

    const directChildren = children.filter((c) => !advisoryIds.has(c.id));
    const advisoryOnly = children.filter((c) => advisoryIds.has(c.id));

    const allChildren = [
      ...directChildren.map((c) => ({ ...c, advisory: false })),
      ...advisoryOnly.map((c) => ({ ...c, advisory: true })),
    ];

    for (let i = 0; i < allChildren.length; i++) {
      const c = allChildren[i];
      const isLast = i === allChildren.length - 1;
      const connector = isLast ? "└── " : "├── ";
      const childIndent = indent + (isLast ? "    " : "│   ");
      if (c.advisory) {
        lines.push(`${indent}${connector}${c.id} (advisory)`);
      } else {
        printTreeRec(c.id, connector, rootIds, byId, childIndent);
      }
    }
  }

  for (const def of rootChecks) {
    printTreeRec(def.id, "", rootIds, byId, "");
    lines.push("");
  }

  lines.push("```");
  lines.push("");
  return lines;
}

function buildDefsByNamespace(defs) {
  const byNS = new Map();
  for (const def of defs) {
    const ns = def.id.split(".")[0];
    if (!byNS.has(ns)) byNS.set(ns, []);
    byNS.get(ns).push(def);
  }
  return byNS;
}

function renderNamespaceDiagram(defs, byId) {
  const lines = [];
  lines.push("## Namespace Overview", "");

  const byNS = buildDefsByNamespace(defs);
  const nsOrder = [
    "root",
    "validation",
    "automated",
    "ai-fixtures",
    "artifact",
    "stack",
    "operations",
    "env",
    "coverage",
    "staleness",
    "known-bad",
    "review",
    "meta",
  ];

  const nsLabels = {
    "ai-fixtures": "AI Fixtures",
    "known-bad": "Known-Bad Fixtures",
    review: "Review & Attestation",
    meta: "Meta / Verifier Health",
  };

  for (const ns of nsOrder) {
    const group = byNS.get(ns);
    if (!group) continue;
    byNS.delete(ns);

    const label = nsLabels[ns] || ns.charAt(0).toUpperCase() + ns.slice(1);
    const supCount = group.filter((d) => hasSupervisorScript(d) || childInputs(d).length > 0).length;
    const leafCount = group.filter((d) => !hasSupervisorScript(d) && childInputs(d).length === 0).length;

    lines.push(`### ${label}`);
    lines.push("");

    if (supCount > 0 && leafCount > 0) {
      lines.push(`${supCount} supervisor${supCount !== 1 ? "s" : ""}, ${leafCount} leaf checks`);
    } else if (supCount > 0) {
      lines.push(`${supCount} supervisor${supCount !== 1 ? "s" : ""}`);
    } else {
      lines.push(`${leafCount} leaf check${leafCount !== 1 ? "s" : ""}`);
    }

    lines.push("");
    for (const def of group.sort((a, b) => a.id.localeCompare(b.id))) {
      const kind = checkKind(def);
      const trig = triggerLabel(def.trigger);
      lines.push(`- [\`${def.id}\`](#${slugifyCheckId(def.id)}) — ${kind}, ${trig}. ${def.description}`);
    }
    lines.push("");
  }

  // Remaining namespaces
  for (const [ns, group] of [...byNS.entries()].sort((a, b) => a[0].localeCompare(b[0]))) {
    const label = ns.charAt(0).toUpperCase() + ns.slice(1);
    const supCount = group.filter((d) => hasSupervisorScript(d) || childInputs(d).length > 0).length;
    const leafCount = group.filter((d) => !hasSupervisorScript(d) && childInputs(d).length === 0).length;

    lines.push(`### ${label}`);
    lines.push("");
    for (const def of group.sort((a, b) => a.id.localeCompare(b.id))) {
      const kind = checkKind(def);
      const trig = triggerLabel(def.trigger);
      lines.push(`- [\`${def.id}\`](#${slugifyCheckId(def.id)}) — ${kind}, ${trig}. ${def.description}`);
    }
    lines.push("");
  }

  return lines;
}

function main() {
  const workspaceDir = path.resolve(process.env.VERIFIER_WORKSPACE || ".");
  const outFile = process.argv[2] || null;

  // Validate path to 'verifier/' workspace (must contain 'checks/')
  if (!fs.existsSync(path.join(workspaceDir, "checks"))) {
    console.error(`Error: '${workspaceDir}' does not contain a 'checks/' directory.`);
    console.error("Set VERIFIER_WORKSPACE to the path of a verifier workspace directory.");
    process.exit(1);
  }

  const defs = loadDefs(workspaceDir);
  const { byId, parentsOf } = buildGraph(defs);

  const lines = [];

  lines.push("# Verifier Check DAG");
  lines.push("");
  lines.push(`_Auto-generated from ${defs.length} check definitions, using summarize.mjs._`);
  lines.push("");

  // Diagram (ASCII tree)
  lines.push(...renderDagAscii(defs, parentsOf, byId));

  // Namespace overview tables
  lines.push(...renderNamespaceDiagram(defs, byId));

  // Table of contents
  lines.push(...renderTableOfContents(defs, parentsOf, byId));

  // Detailed entries
  lines.push("## Check Details", "");
  for (const def of defs) {
    lines.push(...renderCheckDetail(def, parentsOf, byId));
  }

  const output = lines.join("\n");

  if (outFile) {
    fs.writeFileSync(outFile, output, "utf-8");
    console.error(`Wrote ${output.length} bytes to ${outFile}`);
  } else {
    process.stdout.write(output);
  }
}

main();
