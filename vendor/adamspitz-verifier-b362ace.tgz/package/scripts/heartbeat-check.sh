#!/usr/bin/env bash
# heartbeat-check.sh — the ONE piece that lives outside the harness.
# Put it in real OS cron (e.g. every 5 min). It pages you if the scheduler's
# heartbeat is stale, because the scheduler cannot detect its own death.
#
#   */5 * * * * /usr/local/bin/heartbeat-check.sh /path/to/verification-workspace
set -euo pipefail
WORKSPACE="${1:-${VERIFIER_WORKSPACE:-$PWD}}"
HEARTBEAT="${VERIFIER_HEARTBEAT:-$WORKSPACE/state/heartbeat}"
MAX_AGE_SEC="${MAX_AGE_SEC:-180}"   # alert if no tick in 3 min

if [[ ! -f "$HEARTBEAT" ]]; then
  echo "ALERT: verifier heartbeat missing ($HEARTBEAT)" >&2; exit 1
fi
age=$(( $(date +%s) - $(stat -c %Y "$HEARTBEAT") ))
if (( age > MAX_AGE_SEC )); then
  echo "ALERT: verifier scheduler stale — last tick ${age}s ago" >&2
  # wire your pager here (curl webhook, etc.)
  exit 1
fi
