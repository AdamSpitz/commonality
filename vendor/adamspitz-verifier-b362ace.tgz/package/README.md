# verifier

A small harness for the ongoing verification of a complex system.

You can use it for running tests on the code, asking LLMs to make sure the docs make sense, doing monitoring on the live system... any sort of ongoing verification. It's very open-ended; write whatever kinds of checks you want.

**It is a script, not a project.** The harness is ~6 tiny modules that stay small and stable; you'll edit them rarely. All the real, ever-growing work lives in `checks/`, which belong to *your* project, not to this repo.

> **Writing or wiring up checks?** The full how-to is [`skills/using-verifier/SKILL.md`](skills/using-verifier/SKILL.md) — read it before you add or edit a check. This README is the map of the harness itself.

## Motivation

I built this little framework because I was working on a big project that was becoming too complicated for me to verify manually. If I had been the founder or CEO of a company, I would have hired human employees, so that I could assign each of them to be in charge of some portion of the project, and then I could ask them, "Hey, how's your portion of the project going?" and they could each give me a report. But I didn't want to hire humans, I wanted to use LLMs instead.

I didn't want to create a bunch of long-lived always-running AI agents; that struck me as overkill and I thought it would introduce more complexity.

The design I settled on was the simplest thing that I thought could possibly work:
  - you make a big list of "checks" (which could be conventional code or could run an LLM - whatever you choose, it's just a script that runs and produces some JSON, either periodically or in response to some event or whatever);
  - and you can make checks that take the results of other checks as input.

So you can organize the checks into a hierarchy (well, a DAG) until at the very top you have a check that gives you a summary of the state of the entire project.

That's all.

Once I had this basic framework in place (with an [AI skill](./skills/using-verifier/SKILL.md) to teach my coding agent how to use it), I found that it was pretty easy to start offloading all the ongoing concerns that I was previously keeping track of in my head: "make sure we have a check that makes sure the landing page is compelling", "make sure we have a check that the UX is smooth for all the main use cases", "make sure we have a check that watches the logs for errors in prod", etc. It feels like having a company full of employees I can delegate to.

At the time of writing this, I don't have enough experience with it yet to know how well it'll work in practice in the long term.

## The one idea

Everything is a **check**: a command that prints one `Result` JSON object to stdout and exits. The harness never knows what a check *does* — only what it needs to run (its `inputs`), how to run it, and how to route its result.

```json
{ "status": "pass" | "fail" | "uncertain" | "error", "summary": "...", "findings": ... }
```

- **pass** — healthy. Ignored.
- **fail** — the *system* is wrong. Pages you.
- **uncertain** — ran fine, but judgment is ambiguous; wants a smarter look. Queued.
- **error** — the *check* couldn't run. A blind spot. Queued; escalates if it persists.

Exit non-zero, time out, or print garbage and the harness records an `error` for you — **a check cannot hide by crashing.**

Two consequences make this more than a cron runner:

- **There is no separate "supervisor" type.** A supervisor is just a check whose inputs include *other checks' latest results*. The whole hierarchy — which manager summarizes which workers — *emerges* from those inputs. It's a DAG, so one worker can feed several supervisors. A graph of stateless evaluations, not an agent society.
- **A run picks its own next run.** Alongside its status a check may emit `nextRun: { inMinutes: 60 }`, making adaptive backoff (`inMinutes: healthy ? 240 : 5`) trivial and letting an LLM check decide when to look again. The `trigger` in the definition is only the seed and the fallback.
- **A pure check need not re-run when nothing changed.** Set `"memoize": true` in a definition and the harness fingerprints the check's resolved inputs *plus its own builder files* (the existing files named in `command`) before each run; if the fingerprint matches the last run's, it **skips the command entirely** and reuses the prior `Result` (flagged `memoized: true`). This is Nix-style input-addressed caching: re-running a check whose world hasn't changed costs nothing — no subprocess, no LLM tokens — which is what makes an expensive LLM-synthesis check safe to put behind a "give me the report" command you hit repeatedly. Only sound for checks that are pure functions of their *declared* inputs; a leaf that reads the live system directly (not via a declared input) must not set it. `error` and `skipped` results are never memoized — a blind spot is always retried — so a memoized check self-heals after a failure.

The skill covers how to actually write all of this; the rest of this README is what's behind the curtain.

## The harness (`src/` — small and stable)

    types.ts        the Result/Input/Definition contract — read this first
    config.ts       resolves the per-project verification workspace
    inputs.ts       resolves a check's declared inputs; check-side readInputs()
    loader.ts       reads checks/*.def.json, validates the input graph (no cycles, all ids exist)
    runner.ts       resolves inputs, spawns one check, enforces timeout, manufactures `error`
    store.ts        directory-as-index JSON storage + run state
    router.ts       pass=ignore  fail=alert  uncertain=queue  error=queue→alert-if-stale
    scheduler.ts    the only long-running process: due? → run → store → route
    run.ts          one-shot CLI: `verifier-run --workspace <dir> <checkId>`
    heartbeat-check.sh   dead-man's-switch — runs from REAL OS cron, outside all of this

## The verification workspace (per project)

The harness is generic; each project that uses it has a **verification workspace** — the directory where that project's checks, history, and mutable state live. It is not this repo, and not necessarily the project root.

    checks/      YOUR checks (grows forever): *.mjs logic + *.def.json definitions
                 supervisor.mjs    one reusable generic supervisor (folds inputs by a rule)
                 prune.mjs         retention enforcement — itself a check
                 meta/liveness.mjs the silent/overdue watchdog — itself a check
    results/     results/<checkId>/<runId>.json    (rolling, pruned)
    artifacts/   artifacts/<checkId>/<runId>/...    (bulky per-run evidence)
    state/       state/<checkId>.json + heartbeat   (mutable)

Checks are **independent programs that import nothing from the harness** — they read env vars and print one Result. So a check can be written in any language; the `.mjs` examples just run with plain `node` (no build step). See the skill for the authoring details.

## Running

From this repo during development:

    npm run build
    node dist/scheduler.js --workspace /path/to/workspace
    node dist/run.js --workspace /path/to/workspace root      # runs the root supervisor; this IS your dashboard

Install the harness on your PATH:

    npm install -g @adamspitz/verifier

Or, from this checkout while developing the harness itself:

    npm run build
    npm run install:global

Then:

    verifier-scheduler   --workspace /path/to/workspace
    verifier-run         --workspace /path/to/workspace <checkId>
    verifier-run-command                                 # helper for command-based checks
    verifier-tree        --workspace /path/to/workspace [rootCheckId] # interactive tree viewer
    verifier-summarize --workspace /path/to/workspace          # markdown summary of the check definitions
    verifier-heartbeat /path/to/workspace                      # put this in real OS cron

The workspace can also come from `VERIFIER_WORKSPACE`; individual dirs override with `VERIFIER_CHECKS`, `VERIFIER_RESULTS`, `VERIFIER_ARTIFACTS`, `VERIFIER_STATE`, `VERIFIER_HEARTBEAT`.

`verifier-run-command` is a generic check executable for conventional commands. Use it as a check's `command` and pass an argv array in a `params` input; it records stdout/stderr tails in findings, writes bulky output to a `command.log` artifact, treats exit 0 as `pass`, nonzero as `fail`, and spawn/timeout problems as `error`. `verifier-run` enables live output streaming for it, while scheduler runs stay quiet.

```json
{
  "id": "automated.test",
  "name": "npm test",
  "description": "Run npm test.",
  "trigger": { "type": "manual" },
  "retention": { "keep": 3, "keepDays": 14 },
  "command": ["verifier-run-command"],
  "inputs": [
    { "kind": "params", "data": { "label": "npm test", "command": ["npm", "test"], "cwd": "..", "commandTimeoutMs": 120000 } }
  ],
  "timeoutMs": 150000
}
```

`verifier-tree` is the interactive dashboard. It has three modes:

- **views** (the default when the workspace defines `views.json`) — one or more projections of the same evidence DAG. A single view is shown directly, with no tab bar. Multiple views are numbered tabs: Left/Right or `1`–`9` switches views and `a` runs the active view's contextual action. A view can name static check roots or use a read-only source command returning checks plus optional freshness, cost, and summary metadata. Results and individual reruns remain ordinary check results; views never create synthetic evidence.
- **commands** (the default landing screen when the workspace defines a `commands.json`) — a project-defined menu of runnable commands, each shown with a description as you highlight it, plus a synthetic `Open check dashboard` entry. Press Enter to run the highlighted command (in your real terminal, so you see its output and can Ctrl-C), `t` to jump straight to the tree, `j`/`k` move, `l` reloads, `q` quits.
- **tree** — the check DAG browsable by status, with each selected check's details in a pane on the right. A parent consumes its children's latest results: read each branch as **conclusion → supporting evidence**. This is not a folder hierarchy. One result may support several conclusions, so the underlying structure is a DAG and the viewer may show that check in several branches. The tree shows the check's short `name` when the definition provides one, else the human `description` (first sentence/question); the stable check `id` remains in the details pane and CLI. The details pane is a **menu + content subpanel**: the menu lists everything you might want to see for the selected check — `Error details` (when the run errored) or `Why skipped` (for a `skipped` result: its `skip.reason` and how to enable it), one numbered entry per artifact, `Findings`, `Result JSON`, and `Definition` — and the subpanel below it renders the selected entry's content (scrollable). The most relevant entry is pre-selected: `Error details` when the status is `error` (so a failed-to-run check shows you the full error, not a prompt file), otherwise the check's preferred/first artifact, otherwise the findings. Keys: `j`/`k` (or arrows) move the tree selection, Enter/Space expand/collapse a supervisor, `r` re-runs the selected check in place, `l` reloads stored results, `e` edits the selected check's `.def.json` in `$EDITOR` (default `nvim`) and reloads on quit, from any focus, `v` pages the main result file (preferred artifact, else the result JSON) in `$PAGER` — from the details pane, `v` pages the selected entry's file instead, `1`–`9` jump to the Nth artifact, `Tab` cycles focus tree → menu → content → tree (when the **menu** is focused, `j`/`k` move the menu selection; when the **content** subpanel is focused, `j`/`k` and PgUp/PgDn scroll it; `d` toggles between menu and content focus), `c` returns to the commands menu, `f` opens a filter picker (a filter replaces the DAG with a flat list of matching checks; add filters in `src/filters.ts`), `q` quits. Pass an optional check id to open only that subtree and skip the commands landing, e.g. `verifier-tree --workspace verifier facet.docs`.

### Workspace `commands.json`

A workspace may define `commands.json` at its root to populate the commands menu — handy for the project-specific runner scripts (`npm run verifier:go`, deep-cadence cron, wipe/reseed, etc.) that are not part of the harness itself:

```json
{
  "commands": [
    { "name": "Go — top-level report", "description": "…what it does…", "command": ["npm", "run", "verifier:go"] },
    { "name": "Deep cadence", "description": "…~20 min, runs the guarded local stack checks…", "command": ["npm", "run", "verifier:deep-cadence"] }
  ]
}
```

`command` is argv (no shell, preferred) or a single string run through the shell; `cwd` is relative to the verifier workspace (default `.`). Entries with no name or command are skipped. With no `commands.json`, or when a root check id is passed on the command line, the tool opens straight in tree mode.

### Workspace `views.json`

```json
{
  "views": [
    {
      "id": "current-work",
      "label": "Current work",
      "description": "Checks affected by local changes.",
      "source": ["node", "scripts/relevant-checks.mjs"],
      "actionLabel": "run safe checks",
      "action": { "name": "Check current work", "command": ["npm", "run", "verify:work"], "cwd": ".." }
    },
    { "id": "all", "label": "All checks", "description": "Complete DAG.", "checks": ["root"] }
  ]
}
```

Each view needs either `checks` or `source`. By default, selected checks appear
as a concise evidence list; set `includeDescendants` to `true` for a view that
should expose their complete input subgraphs. Source commands run synchronously
with the verification workspace as their working directory and must print only
the JSON envelope described above. (A legacy `labels` key in the envelope is
ignored — row names come from each definition's `name` or `description`.) Actions
use the same argv/string and `cwd`
contract as `commands.json`. `c` still opens the commands menu when one exists.

The optional `presentation` map is keyed by check id. Its `freshness` entry can
mark evidence stale and list human-readable reasons; its `cost` entry can expose
estimated or measured duration, token use, prerequisites, and effects. The tree
combines this with its own input-newer-than-parent detection. Current passes are
bright green, stale passes amber, current failures bright red, and stale
failures orange; glyphs keep the states distinguishable without colour.

### Showing a check's report by default (`display.preferredArtifact`)

A check that writes a report artifact can ask `verifier-tree` to pre-select *that* artifact in the details menu (so its content is shown by default) rather than falling back to the findings, by naming it in the definition. The menu entry's content subpanel renders the artifact's text (scrollable); the other menu entries (Findings, Result JSON, Definition, other artifacts) are a keypress away.

```json
{ "id": "root", "…": "…", "display": { "preferredArtifact": "report.md" } }
```

`preferredArtifact` matches an artifact's `name`, basename(`path`), or full `path`. If omitted, the tree heuristically prefers an artifact named `report*`, then any text/markdown-ish artifact, then the first artifact.

## Design philosophy — three things to deliberately NOT build

- **No database.** Readable JSON on disk; recent history doesn't need queryability.
- **No web dashboard.** `run.ts root` IS the dashboard — a one-shot rollup report.
- **No plugin/agent framework.** The subprocess-emits-JSON contract is the whole API.

If a fresh reader can't understand the harness top-to-bottom in an afternoon, it's drifting toward a project — stop and cut.
